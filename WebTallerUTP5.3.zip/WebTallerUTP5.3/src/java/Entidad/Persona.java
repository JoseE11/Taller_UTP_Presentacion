/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidad;


public class Persona {
 int DNI, telefono, tipo;
  int estado_persona;
 String nombre , ap_paterno , ap_materno, correo_electronico;

 
 
    public Persona() {
        
        
    }

    public Persona(int DNI, int telefono, int tipo, int estado_persona, String nombre, String ap_paterno, String ap_materno, String correo_electronico) {
        this.DNI = DNI;
        this.telefono = telefono;
        this.tipo = tipo;
        this.estado_persona = estado_persona;
        this.nombre = nombre;
        this.ap_paterno = ap_paterno;
        this.ap_materno = ap_materno;
        this.correo_electronico = correo_electronico;
    }
    
    

    public int getEstado_persona() {
        return estado_persona;
    }

    public void setEstado_persona(int estado_persona) {
        this.estado_persona = estado_persona;
    }


    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAp_paterno() {
        return ap_paterno;
    }

    public void setAp_paterno(String ap_paterno) {
        this.ap_paterno = ap_paterno;
    }

    public String getAp_materno() {
        return ap_materno;
    }

    public void setAp_materno(String ap_materno) {
        this.ap_materno = ap_materno;
    }

    public String getCorreo_electronico() {
        return correo_electronico;
    }

    public void setCorreo_electronico(String correo_electronico) {
        this.correo_electronico = correo_electronico;
    }



}
