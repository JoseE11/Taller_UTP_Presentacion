/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Config.Conexion;
import Entidad.Cita;
import Entidad.Cliente;
import Entidad.Tecnico;
import Interfaces.CRUD_Cita;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CitaDAO implements CRUD_Cita {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cita c = new Cita();
   int r;

    public CitaDAO() {
    }

    @Override
    public List listar() {
        ArrayList<Cita> list = new ArrayList<>();
        String sql="select * from citas AS c INNER JOIN persona AS p ON c.dni_tecnico=p.dni where estado_cita = '+1+'";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                Cita ci=new Cita();
                ci.setId_cita(rs.getInt("id_citas"));
                
                ci.setTecnico(new Tecnico());
                ci.getTecnico().setDNI(rs.getInt("dni_tecnico"));
                ci.getTecnico().setNombre(rs.getString("nombres"));
                ci.setCliente(new Cliente());
                ci.getCliente().setDNI(rs.getInt("dni_cliente"));
                 ci.setHora_cita(rs.getTime("hora_cita"));
                ci.setFecha_cita(rs.getDate("fecha_cita"));
               

                list.add(ci);
       }
        } catch (SQLException e) {
                e.printStackTrace(System.out);
        }
        return list;        
    }

    @Override
    public Cita list(int id_cita) {
       String sql="select * from citas where id_citas="+id_cita;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
            //(dni, nombres, apellido_paterno, apellido_materno, id_tipo_persona, distrito, direccion, telefono, correo electronico) "  
                c.setId_cita(rs.getInt("id_citas"));
                c.setTecnico(new Tecnico());
                c.getTecnico().setDNI(rs.getInt("dni_tecnico"));
                
                c.setCliente(new Cliente());
                c.getCliente().setDNI(rs.getInt("dni_cliente"));
                c.setHora_cita(rs.getTime("hora_cita"));
                c.setFecha_cita(rs.getDate("fecha_cita"));
            
            }
        } catch (SQLException e) {
                e.printStackTrace(System.out);
        }
        return c;
    }

    @Override
    public int add(Cita cit) {

       String sql="insert into citas (dni_tecnico, dni_cliente, hora_cita, fecha_cita) "  
                + "values ('"+cit.getTecnico().getDNI()+"',"
                + "'"+cit.getCliente().getDNI()+"','"+cit.getHora_cita()+"',"
                + "'"+cit.getFecha_cita()+"') ";
        //sql="insert into  ( , , ) values ('"++"','"++"','"++"') ";
        try {                                                                                                                                                    
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
                e.printStackTrace(System.out);
      
        }
        return r;  
    }

    @Override
    public int edit(Cita cit) {
        String sql="update citas set id_citas='"+cit.getId_cita()+"',"
            + "dni_tecnico='"+cit.getTecnico().getDNI()+"',"
                + " dni_cliente='"+cit.getCliente().getDNI()+"',"
            + "hora_cita='"+cit.getHora_cita()+"',"
                + "fecha_cita='"+cit.getFecha_cita()+"'"
            + "where id_citas=?" ; 
                 try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
             ps.setInt(1, cit.getId_cita());
            ps.executeUpdate();
           } catch (Exception e) {
                   e.printStackTrace(System.out);
           }
         
        return r;
    }

    @Override
    public int eliminar(Cita cit) {
        String sql="update citas set estado_cita=0 where id_citas=?";
  // String sql="update persona set estado_persona='0' where dni="+dni;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.setInt(1, cit.getId_cita());
            ps.executeUpdate();
        } catch (Exception e) {
                e.printStackTrace(System.out);
        }
        return r;
    }

}
