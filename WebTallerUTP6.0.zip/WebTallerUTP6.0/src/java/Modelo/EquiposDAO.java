/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Config.Conexion;
import Entidad.Equipos;
import Entidad.Persona;
import Interfaces.CRUD_Equipo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class EquiposDAO implements CRUD_Equipo {
    Conexion cn=new Conexion();
Connection con;
PreparedStatement ps;
ResultSet rs;
Equipos e=new Equipos();

    @Override
    public List listar() {
      ArrayList<Equipos>list=new ArrayList<>();
       String sql="select * from equipo AS e "
               + "INNER JOIN tip_equipos AS t ON e.id_tipo_equipo=t.id_tipo "
               + "INNER JOIN marca AS m ON e.id_marca=m.id_marca where e.estado_equipo = 1";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                Equipos equi=new Equipos();
                equi.setPer(new Persona());
                equi.getPer().setDNI(rs.getInt("dni"));
                equi.setId_equipo(rs.getInt("id_equipo"));
                equi.setNombre_tipo_equipo(rs.getString("descripcion"));
                equi.setMarca(rs.getString("nombre_marca"));
                equi.setModelo(rs.getString("modelo"));
                
                list.add(equi);    
            }
                  
        } catch (SQLException e) {
             e.printStackTrace(System.out);
        }
        return list;  
         }

    @Override
    public Equipos list(int id) {
        String sql="select * from equipo AS e "
               + "INNER JOIN tip_equipos AS t ON e.id_tipo_equipo=t.id_tipo "
               + "INNER JOIN marca AS m ON e.id_marca=m.id_marca where id_equipo="+id;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                
                e.setPer(new Persona());
                e.getPer().setDNI(rs.getInt("dni"));
                e.setId_equipo(rs.getInt("id_equipo"));
                e.setNombre_tipo_equipo(rs.getString("descripcion"));
                e.setMarca(rs.getString("nombre_marca"));
                e.setModelo(rs.getString("modelo"));
                e.setEstado(rs.getString("estado"));
            }
                  
        } catch (SQLException e) {
             e.printStackTrace(System.out);
        }
        return e;  
         } 


    @Override
    public boolean add(Equipos equi) {
        
       String sql="insert into equipo (id_tipo_equipo, dni, id_marca, modelo, estado) "  
                + "values ('"+equi.getId_tipo_equipo()+"',"
               + "'"+equi.getPer().getDNI()+"',"
               + "'"+equi.getId_marca()+"',"
               + "'"+equi.getModelo()+"',"
               + "'"+equi.getEstado()+"')";
    
        try {                                                                                                                                                    
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return false;    }

    @Override
    public boolean edit(Equipos equi) {
    String sql="update equipo set id_equipo='"+equi.getId_equipo()+"',"
            + "id_tipo_equipo='"+equi.getId_tipo_equipo()+"',"
            + "dni='"+equi.getPer().getDNI()+"',"
            + "id_marca='"+equi.getId_marca()+"',"
            + " modelo='"+equi.getModelo()+"',"
            + "estado='"+equi.getEstado()+"'"
            + "where id_equipo=?";  
                             
    
        try {                                                                                                                                                    
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.setInt(1, equi.getId_equipo());
            ps.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return false;     
    }

    @Override
    public boolean eliminar(Equipos equi) {
        String sql="update equipo set estado_equipo = 0 where id_equipo=?";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.setInt(1, equi.getId_equipo());
            ps.executeUpdate();
        } catch (Exception e) {
            
        }
        return false ;
    }

}
