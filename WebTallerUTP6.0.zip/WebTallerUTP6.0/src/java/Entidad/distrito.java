/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

/**
 *
 * @author Usuario
 */
public class distrito {
    
    int id_distrito;
    String nombre_distrito;

     public distrito(){
         
     }
    public distrito(int id_distrito, String nombre_distrito) {
        this.id_distrito = id_distrito;
        this.nombre_distrito = nombre_distrito;
    }

    public int getId_distrito() {
        return id_distrito;
    }

    public void setId_distrito(int id_distrito) {
        this.id_distrito = id_distrito;
    }

    public String getNombre_distrito() {
        return nombre_distrito;
    }

    public void setNombre_distrito(String nombre_distrito) {
        this.nombre_distrito = nombre_distrito;
    }
    
    
    
}
