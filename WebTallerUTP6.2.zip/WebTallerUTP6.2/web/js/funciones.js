

$(document).ready(function () {
    
    $("tr #deleteu").click(function (e) {
        e.preventDefault();
        var cod = $(this).parent().find('#codigo').val();
        swal({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }, 
        
        function(isConfirm) {
            if (isConfirm) {
                        eliminarPieza(cod);
                        swal()'Deleted!',
                        'Your file has been deleted.',
                        'success');
            }
        });

    });
    
    function eliminarPieza(cod) {

    var url = "controlador?menu=Piezas&accion=Eliminar&id=" + cod;
    console.log("Eliminar");
    $.ajax({
    type: 'POST',
            url: url,
            async: true,
            success: function (r){
                
          }
    });

}
    
});





