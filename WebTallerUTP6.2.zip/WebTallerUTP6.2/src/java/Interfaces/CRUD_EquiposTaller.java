/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;


import Entidad.EquipoTaller;
import java.util.List;


public interface CRUD_EquiposTaller {
     public List listar();
    public EquipoTaller list(int id_equipo_taller);
    public int add ( EquipoTaller qt);
    public int edit ( EquipoTaller qt);
    public int eliminar (EquipoTaller qt);
    
}
