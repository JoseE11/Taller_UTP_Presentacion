/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Entidad.*;
import Modelo.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "controlador", urlPatterns = {"/controlador"})
public class controlador extends HttpServlet {
ClienteDAO dao = new ClienteDAO();
TecnicoDAO  daotec=new TecnicoDAO ();
EquiposDAO daoequipo= new EquiposDAO();
CitaDAO daocita = new CitaDAO();
PiezaDAO daopieza = new PiezaDAO();
Equipos equ = new Equipos();
Cliente cli = new Cliente();
Tecnico tec = new Tecnico();
Cita cit = new Cita();
Pieza piz = new Pieza();

List<Servicio> servicios = new ArrayList<>();
EquipoTaller et = new EquipoTaller();
EquipoTallerDAO daotaller = new EquipoTallerDAO();
ServicioDAO serdao = new ServicioDAO();
Servicio ser = new Servicio();

List <Hoja_Trabajo_Carrito> listaCarrito = new ArrayList<>();

int item;
int cantidad=1;
double totalPagar=0.0;

int ide;
int ideCliente;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String menu = request.getParameter("menu");
       String accion = request.getParameter("accion");
       if(menu.equals("Cliente")){
           this.cargarDistritos(request);
           switch(accion){
               case "Listar":
                   List lista = dao.listar();
                   request.setAttribute("cliente", lista);
                   request.getRequestDispatcher("Hj_RegistroUsuario.jsp").forward(request, response);
                   break;
               case "Agregar":
                   
                   int dni = Integer.parseInt(request.getParameter("txtDni"));
                    String nom = request.getParameter("txtNopmbre");
                    String ape_pa = request.getParameter("txtApellido_pa");
                    String ape_ma = request.getParameter("txtApellido_ma");
                    int dis = Integer.parseInt(request.getParameter("txtDistrito"));
                    String dire = request.getParameter("txtDireccion");
                    int tel = Integer.parseInt(request.getParameter("txtTelefono"));
                    String cor = request.getParameter("txtCorreo");
                    
                    cli.setDNI(dni);
                    cli.setNombre(nom);
                    cli.setAp_paterno(ape_pa);
                    cli.setAp_materno(ape_ma);
                    cli.setId_distrito(dis);
                    cli.setDireccion(dire);
                    cli.setTelefono(tel);
                    cli.setCorreo_electronico(cor);
                    dao.add(cli);
                    request.getRequestDispatcher("controlador?menu=Cliente&accion=Lista").forward(request, response);
                   
                   break;
               case "Editar":
                   ide=Integer.parseInt(request.getParameter("id"));
                   Persona p=dao.list(ide);
                   request.setAttribute("cliente", p);
                   request.getRequestDispatcher("Ed_Cliente.jsp").forward(request, response);
                   break;
                case "Actualizar":
                    int dni1 = Integer.parseInt(request.getParameter("txtDni"));
                    String nom1 = request.getParameter("txtNopmbre");
                    String ape_pa1 = request.getParameter("txtApellido_pa");
                    String ape_ma1 = request.getParameter("txtApellido_ma");
                    int dis1 = Integer.parseInt(request.getParameter("txtDistrito"));
                    String dire1 = request.getParameter("txtDireccion");
                    int tel1 = Integer.parseInt(request.getParameter("txtTelefono"));
                    String cor1 = request.getParameter("txtCorreo");
                    cli.setDNI(dni1);
                    cli.setNombre(nom1);
                    cli.setAp_paterno(ape_pa1);
                    cli.setAp_materno(ape_ma1);
                    cli.setId_distrito(dis1);
                    cli.setDireccion(dire1);
                    cli.setTelefono(tel1);
                    cli.setCorreo_electronico(cor1);
                    dao.edit(cli);
                    request.getRequestDispatcher("controlador?menu=Cliente&accion=Lista").forward(request, response);
                   break;
               case "Eliminar":
                     ide=Integer.parseInt(request.getParameter("id"));
                     cli.setDNI(ide);
                     dao.eliminar(cli);
                     request.getRequestDispatcher("controlador?menu=Cliente&accion=Lista").forward(request, response);
                   break;
               case "Lista":
                     List lista1 = dao.listar();
                     request.setAttribute("cliente", lista1);
                     request.getRequestDispatcher("List_Cliente.jsp").forward(request, response);
                   break;
             
               
               default:
                   throw new AssertionError();
           }
           
       }
       if(menu.equals("Tecnico")){
           this.cargarHorarios(request);
           switch(accion){
               case "Listar":
                   List lista = daotec.listar();
                   request.setAttribute("tecnico", lista);
                   request.getRequestDispatcher("Ad_Tecnico.jsp").forward(request, response);
                   break;
               case "Agregar":
                   int dni = Integer.parseInt(request.getParameter("txtDni"));
                    String nom = request.getParameter("txtNombre");
                    String ape_pa = request.getParameter("txtApellido_pa");
                    String ape_ma = request.getParameter("txtApellido_ma");
                    int ho = Integer.parseInt(request.getParameter("txtHorario"));
                    String esp = request.getParameter("txtEspecialidad");
                    String exp = request.getParameter("txtExperiencia");
                    int tel = Integer.parseInt(request.getParameter("txtTelefono"));
                    String cor = request.getParameter("txtCorreo");
                    
                    tec.setDNI(dni);
                    tec.setNombre(nom);
                    tec.setAp_paterno(ape_pa);
                    tec.setAp_materno(ape_ma);
                    tec.setHorario(ho);
                    tec.setEspecialidad(esp);
                    tec.setExperiencia_labo(exp);
                    tec.setTelefono(tel);
                    tec.setCorreo_electronico(cor);
                    
                    daotec.add(tec);
                    request.getRequestDispatcher("controlador?menu=Tecnico&accion=Lista").forward(request, response);
                   break;
               case "Editar":
                   ide=Integer.parseInt(request.getParameter("id"));
                   Persona p=daotec.list(ide);
                   request.setAttribute("tecnico", p);
                  
                   request.getRequestDispatcher("Ed_Tecnico.jsp").forward(request, response);
                   break;
                case "Actualizar":
                    int dni1 = Integer.parseInt(request.getParameter("txtDni"));
                    String nom1 = request.getParameter("txtNombre");
                    String ape_pa1 = request.getParameter("txtApellido_pa");
                    String ape_ma1 = request.getParameter("txtApellido_ma");
                    int ho1 = Integer.parseInt(request.getParameter("txtHorario"));
                    String esp1 = request.getParameter("txtEspecialidad");
                    String exp1 = request.getParameter("txtExperiencia");
                    int tel1 = Integer.parseInt(request.getParameter("txtTelefono"));
                    String cor1 = request.getParameter("txtCorreo");
                    
                    tec.setDNI(dni1);
                    tec.setNombre(nom1);
                    tec.setAp_paterno(ape_pa1);
                    tec.setAp_materno(ape_ma1);
                    tec.setHorario(ho1);
                    tec.setEspecialidad(esp1);
                    tec.setExperiencia_labo(exp1);
                    tec.setTelefono(tel1);
                    tec.setCorreo_electronico(cor1);
                    daotec.edit(tec);
                    request.getRequestDispatcher("controlador?menu=Tecnico&accion=Lista").forward(request, response);
                   break;
               case "Eliminar":
                     ide=Integer.parseInt(request.getParameter("id"));
                     tec.setDNI(ide);
                     daotec.eliminar(tec);
                     request.getRequestDispatcher("controlador?menu=Tecnico&accion=Lista").forward(request, response);
                   break;
                   
               case "Lista":
                     List lista1 = daotec.listar();
                     request.setAttribute("tecnico", lista1);
                     request.getRequestDispatcher("List_Tecnico.jsp").forward(request, response);
                   break;
               default:
                   throw new AssertionError();
           }
        
       }
       if(menu.equals("Equipo")){
           this.cargarTipoEquipos(request);
           this.cargarMarca(request);
           switch(accion){
               case "Listar":
                   List lista = daoequipo.listar();
                   request.setAttribute("equipo", lista);
                   break;
               case "Agregar":
                    int dni = Integer.parseInt(request.getParameter("txtDni"));
                    
                    int tip1 = Integer.parseInt(request.getParameter("txtTipo"));
                    int mar1 = Integer.parseInt(request.getParameter("txtMarca"));
                    String mod = request.getParameter("txtModelo");
                    String est = request.getParameter("txtEstado");
                    equ.setPer(new Persona());
                    equ.getPer().setDNI(dni);
                    
                    equ.setId_tipo_equipo(tip1);
                    equ.setId_marca(mar1);
                    equ.setModelo(mod);
                    equ.setEstado(est);
                    daoequipo.add(equ);

                    request.getRequestDispatcher("controlador?menu=Equipo&accion=Listar").forward(request, response);
                   break;
               case "Dni":
                   ide=Integer.parseInt(request.getParameter("id"));
                   Persona p=dao.list(ide);
                   request.setAttribute("cliente", p);
                   request.getRequestDispatcher("controlador?menu=Equipo&accion=Listar").forward(request, response);
                   break;
               case "Editar":
                   ide=Integer.parseInt(request.getParameter("id"));
                   Equipos e=daoequipo.list(ide);
                   request.setAttribute("equipos", e);
                  
                   request.getRequestDispatcher("Ed_Equipo.jsp").forward(request, response);
                   break;
                case "Actualizar":
                    int dni1 = Integer.parseInt(request.getParameter("txtDni"));
                    int id = Integer.parseInt(request.getParameter("txtId"));
                    int tip2 = Integer.parseInt(request.getParameter("txtTipo"));
                    int mar2 = Integer.parseInt(request.getParameter("txtMarca"));
                    String mod1 = request.getParameter("txtModelo");
                    String est1 = request.getParameter("txtEstado");
                    equ.setPer(new Persona());
                    equ.getPer().setDNI(dni1);
                    equ.setId_equipo(id);
                    equ.setId_tipo_equipo(tip2);
                    equ.setId_marca(mar2);
                    equ.setModelo(mod1);
                    equ.setEstado(est1);
                    daoequipo.edit(equ);
                    
                    request.getRequestDispatcher("controlador?menu=Equipo&accion=Listar").forward(request, response);
                   break;
               case "Eliminar":
                     ide=Integer.parseInt(request.getParameter("id"));
                     equ.setId_equipo(ide);
                     daoequipo.eliminar(equ);
                     request.getRequestDispatcher("controlador?menu=Equipo&accion=Listar").forward(request, response);
                   break;
                   
                case "Lista":
                    List lista2 = daoequipo.listar();
                    request.setAttribute("equipo", lista2);
                     request.getRequestDispatcher("List_Equipos.jsp").forward(request, response);
                    
                    
                    break;
               default:
                   throw new AssertionError();
           }
           request.getRequestDispatcher("Hj_RegistroEquipos.jsp").forward(request, response);
       }
       if(menu.equals("Cita")){
           this.cargarDistritos(request);
           switch(accion){
               case "ListarTecnicos":
                   List listatec = daotec.listar();
                   request.setAttribute("tecnico1", listatec);
                    
                   request.getRequestDispatcher("Seleccionar_Tecnico.jsp").forward(request, response);
                    break;
               case "ListarCitas":
                   List lista = daocita.listar();
                   request.setAttribute("cita", lista);
                    request.getRequestDispatcher("Tabla_citas.jsp").forward(request, response);
                   break;
               case "DniCliente":
                   ide = Integer.parseInt(request.getParameter("id"));
                   Persona c = dao.list(ide);
                   request.setAttribute("cliente", c);
                   request.getRequestDispatcher("controlador?menu=Cita&accion=ListarTecnicos").forward(request, response);

                   break;
                 case "DniTecnico":
                   ide=Integer.parseInt(request.getParameter("id"));
                   Persona p=daotec.list(ide);
                   request.setAttribute("tecnico", p);
                   
                   int ide1 = Integer.parseInt(request.getParameter("ide1"));
                   Persona ct = dao.list(ide1);
                   request.setAttribute("cliente", ct);
                   request.getRequestDispatcher("Ad_citas.jsp").forward(request, response);
                   break;
               case "Editar":
                   ide = Integer.parseInt(request.getParameter("id"));
                   Cita cita = daocita.list(ide);
                   request.setAttribute("cita", cita);
                   request.getRequestDispatcher("Ed_cita.jsp").forward(request, response);

                   break;    
               case "Agregar":
                   
                    int dni_cliente = Integer.parseInt(request.getParameter("txtDniCliente"));
                    int dni_tecnico = Integer.parseInt(request.getParameter("txtADniTecnico"));
                    Date fecha = Date.valueOf(request.getParameter("txtFecha"));
                    Time hora = Time.valueOf(request.getParameter("txtHora"));
                    
                    cit.setCliente(new Cliente());
                    cit.setTecnico(new Tecnico());
                    cit.getCliente().setDNI(dni_cliente);
                    cit.getTecnico().setDNI(dni_tecnico);
                    
                    cit.setFecha_cita(fecha);
                    cit.setHora_cita(hora);

                    daocita.add(cit);
                    request.getRequestDispatcher("controlador?menu=Cita&accion=ListarCitas").forward(request, response);
                   break;
               case "Actualizar":
                   int id = Integer.parseInt(request.getParameter("txtId"));
                   int dni_cliente1 = Integer.parseInt(request.getParameter("txtDniCliente"));
                    int dni_tecnico1 = Integer.parseInt(request.getParameter("txtADniTecnico"));
                    Date fecha1 = Date.valueOf(request.getParameter("txtFecha"));
                    Time hora1 = Time.valueOf(request.getParameter("txtHora"));
                    cit.setId_cita(id);
                    cit.setCliente(new Cliente());
                    cit.setTecnico(new Tecnico());
                    cit.getCliente().setDNI(dni_cliente1);
                    cit.getTecnico().setDNI(dni_tecnico1);
                    
                    cit.setFecha_cita(fecha1);
                    cit.setHora_cita(hora1);

                   daocita.edit(cit);
                   request.getRequestDispatcher("controlador?menu=Cita&accion=ListarCitas").forward(request, response);
                   break;
                   
               case "Eliminar":
                     int idecita=Integer.parseInt(request.getParameter("id"));
                     cit.setId_cita(idecita);
                     daocita.eliminar(cit);
                     request.getRequestDispatcher("controlador?menu=Cita&accion=ListarCitas").forward(request, response);
                   break;
               default:
                   throw new AssertionError();
           }
            
           
       }

          if(menu.equals("Piezas")){
           switch(accion){
               case "Listar":
                   List lista = daopieza.listar();
                   request.setAttribute("pieza", lista);
                   break;
               case "Agregar":
                     String nombre_pieza = request.getParameter("txtPieza_n");
                     String des1 = request.getParameter("txtPieza_d");
        
                    piz.setNombre_pieza(nombre_pieza);
                    piz.setDescripcion(des1);
            
                    daopieza.add(piz);

                    request.getRequestDispatcher("controlador?menu=Piezas&accion=Lista").forward(request, response);
                   break;
               case "Editar":
                   ide=Integer.parseInt(request.getParameter("id"));
                   Pieza e=daopieza.list(ide);
                   request.setAttribute("pieza", e);
                  
                   request.getRequestDispatcher("Ed_Pieza.jsp").forward(request, response);
                   break;
                   
                   
                   
                   /**/
                case "Actualizar":
                     int id_pieza = Integer.parseInt(request.getParameter("txtid_pieza"));

                     String nombre_pieza1 = request.getParameter("txtPieza_n");
                     String des2 = request.getParameter("txtPieza_d");
                    piz.setId_pieza(id_pieza);
                    piz.setNombre_pieza(nombre_pieza1);
                    piz.setDescripcion(des2);
                    
                    daopieza.edit(piz);
                    
                    request.getRequestDispatcher("controlador?menu=Piezas&accion=Lista").forward(request, response);
                   break;
               case "Eliminar":
                   
                   
                   if (request.getParameter("id") != null){
                       
                     ide=Integer.parseInt(request.getParameter("id"));
                     piz.setId_pieza(ide);
                
                       try {
                                daopieza.eliminar(piz);
                                 request.getRequestDispatcher("controlador?menu=Piezas&accion=Lista").forward(request, response);
                   
                     
                       } catch (Exception e1) {
                           
                           request.setAttribute("msje", e1.getMessage());
                       }
                   } else {
                   request.setAttribute("msje", "Error");
                   
                   }
                     request.getRequestDispatcher("controlador?menu=Piezas&accion=Lista").forward(request, response);
                   
                     
                     
                     break;
                     
                     
               case "Lista":
                     List lista1 = daopieza.listar();
                     request.setAttribute("pieza", lista1);
                     request.getRequestDispatcher("List_Piezas.jsp").forward(request, response);
                   break;     
                     
                     
               default:
                   throw new AssertionError();
           }
           request.getRequestDispatcher("Ad_Piezas.jsp").forward(request, response);
       }
          
       if(menu.equals("Servicios")){
           switch(accion){
               case "Listar":
                 List lista4 = serdao.listar();
                 request.setAttribute("servicios", lista4);
                 request.getRequestDispatcher("Hj_Salida_2.jsp").forward(request, response);

                   break;
             case "Agregar":
                   int ids=Integer.parseInt(request.getParameter("id"));
                   ser =serdao.listarId(ids);
                   item=item+1;
                   Hoja_Trabajo_Carrito car = new Hoja_Trabajo_Carrito();
                   car.setId_hoja_trabajo(item);
                   car.setIdServicio(ser.getId_servicio());
                   car.setNombres(ser.getNombre_servicio());
                   car.setDescripcion(ser.getNombre_servicio());
                   car.setPrecioServicio(ser.getSub_monto());
                   car.setCantidad(cantidad);
                   car.setSubTotal(cantidad*ser.getSub_monto());
                   listaCarrito.add(car);
                   request.setAttribute("contador", listaCarrito.size());
                    request.getRequestDispatcher("controlador?menu=Servicios&accion=Listar").forward(request, response);

                   break;
            case "Carrito":
                  totalPagar=0.0;
                  request.setAttribute("carrito", listaCarrito);
                  for (int i = 0; i < listaCarrito.size(); i++) {
                   totalPagar=totalPagar+listaCarrito.get(i).getSubTotal();
                }
                  
                  request.setAttribute("totalPagar", totalPagar);
                  request.getRequestDispatcher("Carrito.jsp").forward(request, response);

                  break;
     
               default:
               throw new AssertionError();
        
           }
           
       }
      
       if(menu.equals("Taller")){
           this.cargarDistritos(request);
           switch(accion){
               case "Listar":
                   List listaTaller = daotaller.listar();
                   request.setAttribute("taller", listaTaller);
                    
                   request.getRequestDispatcher("TablaEquipoTaller.jsp").forward(request, response);
                    break;
                case "ListarTecnicos":
                   List listatec = daotec.listar();
                   request.setAttribute("tecnico1", listatec);

                   request.getRequestDispatcher("Asignar_Tecnico_Taller.jsp").forward(request, response);
                   break;
               
                 case "DniTecnico":
                   ide=Integer.parseInt(request.getParameter("dni"));
                   Persona p=daotec.list(ide);
                   request.setAttribute("tecnico", p);
                   
                   ide=Integer.parseInt(request.getParameter("id"));
                   Equipos e=daoequipo.list(ide);
                   request.setAttribute("equipos", e);
                   request.getRequestDispatcher("Ad_Tecnico_Taller.jsp").forward(request, response);
                   break;
               case "IdEquipo":
                   ide=Integer.parseInt(request.getParameter("id"));
                   Equipos eq=daoequipo.list(ide);
                   request.setAttribute("equipos", eq);
                   request.getRequestDispatcher("controlador?menu=Taller&accion=ListarTecnicos").forward(request, response);

                   break;    
               case "Agregar":
                   
                    int id_equipo = Integer.parseInt(request.getParameter("txtId"));
                    int dni_tecnico = Integer.parseInt(request.getParameter("txtADniTecnico"));
                    Date fecha = Date.valueOf(request.getParameter("txtFecha"));
                    
                    et.setEquipo(new Equipos());
                    et.getEquipo().setId_equipo(id_equipo);
                    et.setTecnico(new Tecnico());
                    et.getTecnico().setDNI(dni_tecnico);
                    et.setFecha(fecha);
                    

                    daotaller.add(et);
                    request.getRequestDispatcher("controlador?menu=Taller&accion=Listar").forward(request, response);
                   break;
                 case "Editar":
                   int id = Integer.parseInt(request.getParameter("id"));
                   EquipoTaller ete = daotaller.list(id);
                   request.setAttribute("taller", ete);
                   request.getRequestDispatcher("Ed_Tecnico_Taller.jsp").forward(request, response);

                   break; 
               case "Actualizar":
                  int id_equipo_taller = Integer.parseInt(request.getParameter("txtId"));
                  int id_equipo1 = Integer.parseInt(request.getParameter("txtIdEquipo"));
                    int dni_tecnico1 = Integer.parseInt(request.getParameter("txtADniTecnico"));
                    Date fecha1 = Date.valueOf(request.getParameter("txtFecha"));
                    
                    et.setEquipo(new Equipos());
                    et.getEquipo().setId_equipo(id_equipo1);
                    et.setId_equipo_taller(id_equipo_taller);
                    et.setTecnico(new Tecnico());
                    et.getTecnico().setDNI(dni_tecnico1);
                    et.setFecha(fecha1);
                    
                   daotaller.edit(et);
                   request.getRequestDispatcher("controlador?menu=Taller&accion=Listar").forward(request, response);
                   break;
                   
               case "Eliminar":
                     int idetaller=Integer.parseInt(request.getParameter("id"));
                     et.setId_equipo_taller(idetaller);
                     daotaller.eliminar(et);
                     request.getRequestDispatcher("controlador?menu=Taller&accion=Listar").forward(request, response);
                   break;
               default:
                   throw new AssertionError();
           }
            
           
       }
       
       
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    private void cargarDistritos(HttpServletRequest request){
        DAODistrito daodi = new DAODistrito();
        List<distrito> dist = null;
        try{
            dist = daodi.listar();
            request.setAttribute("distrito", dist);
        }catch(Exception e){
            
        }finally{
            dist=null;
            daodi=null;
        }
    }
    private void cargarHorarios(HttpServletRequest request){
        DAOHorario dao = new DAOHorario();
        List<horario> dist = null;
        try{
            dist = dao.listar();
            request.setAttribute("horario", dist);
        }catch(Exception e){
            
        }finally{
            dist=null;
            dao=null;
        }
    }
    private void cargarTipoEquipos(HttpServletRequest request){
        DAOTipo_Equipos daoe = new DAOTipo_Equipos();
        List<tipo_equipo> tip = null;
        try{
            tip = daoe.listar();
            request.setAttribute("tip_equipos", tip);
        }catch(Exception e){
            
        }finally{
            tip=null;
            daoe=null;
        }
    }
    private void cargarMarca(HttpServletRequest request){
        MarcaDAO daom = new MarcaDAO();
        List<Marca> mar = null;
        try{
            mar = daom.listar();
            request.setAttribute("marca", mar);
        }catch(Exception e){
            
        }finally{
            mar=null;
            daom=null;
        }
    }
}
