/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

/**
 *
 * @author Usuario
 */
public class Equipos {
    
    String marca, modelo,nombre_tipo_equipo,estado;
    int id_equipo, id_tipo_equipo, id_marca;
    Persona per;
     boolean estado_equipo;
     public Equipos(){
}

    public Equipos(String marca, String modelo, String nombre_tipo_equipo, String estado, int id_equipo, int id_tipo_equipo, int id_marca, Persona per, boolean estado_equipo) {
        this.marca = marca;
        this.modelo = modelo;
        this.nombre_tipo_equipo = nombre_tipo_equipo;
        this.estado = estado;
        this.id_equipo = id_equipo;
        this.id_tipo_equipo = id_tipo_equipo;
        this.id_marca = id_marca;
        this.per = per;
        this.estado_equipo = estado_equipo;
    }

    

    public String getNombre_tipo_equipo() {
        return nombre_tipo_equipo;
    }

    public void setNombre_tipo_equipo(String nombre_tipo_equipo) {
        this.nombre_tipo_equipo = nombre_tipo_equipo;
    }

    public int getId_marca() {
        return id_marca;
    }

    public void setId_marca(int id_marca) {
        this.id_marca = id_marca;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getId_equipo() {
        return id_equipo;
    }

    public void setId_equipo(int id_equipo) {
        this.id_equipo = id_equipo;
    }

    public int getId_tipo_equipo() {
        return id_tipo_equipo;
    }

    public void setId_tipo_equipo(int id_tipo_equipo) {
        this.id_tipo_equipo = id_tipo_equipo;
    }

    public Persona getPer() {
        return per;
    }

    public void setPer(Persona per) {
        this.per = per;
    }

    public boolean isEstado_equipo() {
        return estado_equipo;
    }

    public void setEstado_equipo(boolean estado_equipo) {
        this.estado_equipo = estado_equipo;
    }
 
     
}


