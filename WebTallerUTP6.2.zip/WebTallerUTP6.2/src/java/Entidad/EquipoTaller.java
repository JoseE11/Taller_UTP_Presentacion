/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

import java.sql.Date;



public class EquipoTaller {
    
    Equipos equipo;
    Tecnico tecnico;
    int id_equipo_taller;
    Date fecha;
     public EquipoTaller(){
         
     }
    public EquipoTaller(Equipos equipo, Tecnico tecnico, int id_equipo_taller, Date fecha) {
        this.equipo = equipo;
        this.tecnico = tecnico;
        this.id_equipo_taller = id_equipo_taller;
        this.fecha = fecha;
    }

    public Equipos getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipos equipo) {
        this.equipo = equipo;
    }

    public Tecnico getTecnico() {
        return tecnico;
    }

    public void setTecnico(Tecnico tecnico) {
        this.tecnico = tecnico;
    }

    public int getId_equipo_taller() {
        return id_equipo_taller;
    }

    public void setId_equipo_taller(int id_equipo_taller) {
        this.id_equipo_taller = id_equipo_taller;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    
    
}
