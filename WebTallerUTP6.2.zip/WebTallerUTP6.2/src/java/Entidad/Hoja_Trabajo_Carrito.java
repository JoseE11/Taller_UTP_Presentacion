/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidad;


public class Hoja_Trabajo_Carrito {
    int id_hoja_trabajo, idServicio;
    String nombres , descripcion;
    double precioServicio;
    int cantidad;
    double subTotal;

    public Hoja_Trabajo_Carrito() {
    }

    public Hoja_Trabajo_Carrito(int id_hoja_trabajo, int idServicio, String nombres, String descripcion, double precioServicio, int cantidad, double subTotal) {
        this.id_hoja_trabajo = id_hoja_trabajo;
        this.idServicio = idServicio;
        this.nombres = nombres;
        this.descripcion = descripcion;
        this.precioServicio = precioServicio;
        this.cantidad = cantidad;
        this.subTotal = subTotal;
    }

    public int getId_hoja_trabajo() {
        return id_hoja_trabajo;
    }

    public void setId_hoja_trabajo(int id_hoja_trabajo) {
        this.id_hoja_trabajo = id_hoja_trabajo;
    }

    public int getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(int idServicio) {
        this.idServicio = idServicio;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecioServicio() {
        return precioServicio;
    }

    public void setPrecioServicio(double precioServicio) {
        this.precioServicio = precioServicio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }
    
    
    
}
