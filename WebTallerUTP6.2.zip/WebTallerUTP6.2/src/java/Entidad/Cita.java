/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidad;

import java.sql.Date;
import java.sql.Time;

public class Cita {
    int id_cita;
    Tecnico tecnico;
    Cliente cliente;
    
    int estado_cita;
    Date fecha_cita;
    Time hora_cita;

    public Cita() {
    }

    public Cita(int id_cita, Tecnico tecnico, Cliente cliente, int estado_cita, Date fecha_cita, Time hora_cita) {
        this.id_cita = id_cita;
        this.tecnico = tecnico;
        this.cliente = cliente;
        this.estado_cita = estado_cita;
        this.fecha_cita = fecha_cita;
        this.hora_cita = hora_cita;
    }
   

    public int getId_cita() {
        return id_cita;
    }

    public void setId_cita(int id_cita) {
        this.id_cita = id_cita;
    }

    public Tecnico getTecnico() {
        return tecnico;
    }

    public void setTecnico(Tecnico tecnico) {
        this.tecnico = tecnico;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public int getEstado_cita() {
        return estado_cita;
    }

    public void setEstado_cita(int estado_cita) {
        this.estado_cita = estado_cita;
    }

    public Date getFecha_cita() {
        return fecha_cita;
    }

    public void setFecha_cita(Date fecha_cita) {
        this.fecha_cita = fecha_cita;
    }

    public Time getHora_cita() {
        return hora_cita;
    }

    public void setHora_cita(Time hora_cita) {
        this.hora_cita = hora_cita;
    }

    

    
    
    
    
}
