/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Config.Conexion;
import Entidad.*;
import Entidad.EquipoTaller;
import Interfaces.CRUD_EquiposTaller;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class EquipoTallerDAO implements CRUD_EquiposTaller{
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cita c = new Cita();
    EquipoTaller e=new EquipoTaller();
   int r;
   public EquipoTallerDAO(){
       
   }
    @Override
    public List listar() {
        ArrayList<EquipoTaller> list = new ArrayList<>();
        String sql="select * from equipos_taller AS t INNER JOIN persona AS p ON t.dni_tecnico=p.dni INNER JOIN equipo AS e ON t.id_equipo=e.id_equipo  INNER JOIN tip_equipos AS q ON e.id_tipo_equipo=q.id_tipo INNER JOIN marca AS m ON e.id_marca=m.id_marca where estado_equipos_taller =1";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                EquipoTaller et=new EquipoTaller();
                et.setId_equipo_taller(rs.getInt("id_equipos_taller"));
                
                et.setTecnico(new Tecnico());
                et.getTecnico().setDNI(rs.getInt("dni_tecnico"));
                et.getTecnico().setNombre(rs.getString("nombres"));
                
                et.setEquipo(new Equipos());
                et.getEquipo().setPer(new Persona());
                et.getEquipo().getPer().setDNI(rs.getInt("dni"));
                et.getEquipo().setMarca(rs.getString("nombre_marca"));
                et.getEquipo().setModelo(rs.getString("modelo"));
                et.getEquipo().setNombre_tipo_equipo(rs.getString("descripcion"));
                et.getEquipo().setEstado(rs.getString("estado"));

                et.setFecha(rs.getDate("fecha"));
               

                list.add(et);
       }
        } catch (SQLException e) {
                e.printStackTrace(System.out);
        }
        return list; 
    }

    @Override
    public EquipoTaller list(int id_equipo_taller) {
         String sql="select * from equipos_taller AS t INNER JOIN persona AS p ON t.dni_tecnico=p.dni INNER JOIN equipo AS e ON t.id_equipo=e.id_equipo  INNER JOIN tip_equipos AS q ON e.id_tipo_equipo=q.id_tipo INNER JOIN marca AS m ON e.id_marca=m.id_marca where id_equipos_taller ="+id_equipo_taller;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                
               e.setId_equipo_taller(rs.getInt("id_equipos_taller"));
                
                e.setTecnico(new Tecnico());
                e.getTecnico().setDNI(rs.getInt("dni_tecnico"));
                e.getTecnico().setNombre(rs.getString("nombres"));
                
                e.setEquipo(new Equipos());
                e.getEquipo().setPer(new Persona());
                e.getEquipo().getPer().setDNI(rs.getInt("dni"));
                e.getEquipo().setId_equipo(rs.getInt("id_equipo"));
                e.getEquipo().setMarca(rs.getString("nombre_marca"));
                e.getEquipo().setModelo(rs.getString("modelo"));
                e.getEquipo().setNombre_tipo_equipo(rs.getString("descripcion"));
                e.getEquipo().setEstado(rs.getString("estado"));

                e.setFecha(rs.getDate("fecha"));
               
       }
        } catch (SQLException e) {
                e.printStackTrace(System.out);
        }
        return e; 
    }

    @Override
    public int add(EquipoTaller qt) {
         String sql="insert into equipos_taller (dni_tecnico, id_equipo, fecha) "  
                + "values ('"+qt.getTecnico().getDNI()+"',"
                + "'"+qt.getEquipo().getId_equipo()+"',"
                + "'"+qt.getFecha()+"') ";
        //sql="insert into  ( , , ) values ('"++"','"++"','"++"') ";
        try {                                                                                                                                                    
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
                e.printStackTrace(System.out);
      
        }
        return r;  
    }

    @Override
    public int edit(EquipoTaller qt) {
         String sql="update equipos_taller set id_equipos_taller='"+qt.getId_equipo_taller()+"',"
            + "dni_tecnico='"+qt.getTecnico().getDNI()+"',"
            + "id_equipo='"+qt.getEquipo().getId_equipo()+"',"
             + "fecha='"+qt.getFecha()+"'"
            + "where id_equipos_taller=?" ; 
                 try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
             ps.setInt(1, qt.getId_equipo_taller());
            ps.executeUpdate();
           } catch (Exception e) {
                   e.printStackTrace(System.out);
           }
         
        return r;
    }

    @Override
    public int eliminar(EquipoTaller qt) {
String sql="update equipos_taller set estado_equipos_taller=0 where id_equipos_taller=?";
  // String sql="update persona set estado_persona='0' where dni="+dni;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.setInt(1,  qt.getId_equipo_taller());
            ps.executeUpdate();
        } catch (Exception e) {
                e.printStackTrace(System.out);
        }
        return r;    }
    
}
