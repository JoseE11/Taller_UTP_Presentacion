/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;


import Config.Conexion;
import Entidad.Servicio;
import Interfaces.CRUD_Servicios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;


public class ServicioDAO implements CRUD_Servicios {

Conexion cn=new Conexion();
Connection con;
PreparedStatement ps;
ResultSet rs;


    @Override
    public List listar() {
            List<Servicio>servicios=new ArrayList();
            String sql="select * from servicios";
            try
                {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
               Servicio s = new Servicio();
                s.setId_servicio(rs.getInt(1));
                s.setNombre_servicio(rs.getString(2));
                s.setDescripcion_servicio(rs.getString(3));
                s.setSub_monto(rs.getDouble(4));
                servicios.add(s);
                
            }
            
                } catch (Exception e){
                          e.printStackTrace(System.out);
                }
            return servicios;
            
        }
    
    
      public Servicio listarId(int id) {
       
            String sql="select * from servicios where id_servicio="+id;
            Servicio s=new Servicio();
            try
                {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
               s.setId_servicio(rs.getInt(1));
               s.setNombre_servicio(rs.getString(2));
               s.setDescripcion_servicio(rs.getString(3));
               s.setSub_monto(rs.getDouble(4));
                
            }
            
                } catch (Exception e){
                          e.printStackTrace(System.out);
                }
            return s;
            
        }
    
    
    
    
}
