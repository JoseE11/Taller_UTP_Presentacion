/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Config.Conexion;
import Entidad.Marca;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MarcaDAO {
    Conexion cn=new Conexion();
Connection con;
PreparedStatement ps;
ResultSet rs;

     
public List listar() {
    ArrayList<Marca>list=new ArrayList<>();
       String sql="select * from marca";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                Marca mar=new Marca();
                mar.setId_marca(rs.getInt(1));
                mar.setMarca(rs.getString(2));
                list.add(mar);
       }
        } catch (SQLException e) {
        }
        return list;    
    }
}
