$("#botModal").on("click",function(){
    $("#modal-date").modal();
});

$('.fj-date').datepicker({
    formart:"dd/mm/yyyy"
});

